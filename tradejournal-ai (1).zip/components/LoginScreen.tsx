import React, { useState } from 'react';
import { Activity, ArrowRight, ShieldCheck, UserPlus, LogIn } from 'lucide-react';
import { signIn, signUp } from '../services/storageService';
import { UserSettings } from '../types';

interface LoginScreenProps {
  onLogin: (user: UserSettings) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    name: ''
  });
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    // Small artificial delay for better UX feeling
    setTimeout(() => {
      try {
        if (isLogin) {
          const user = signIn(formData.username, formData.password);
          onLogin(user);
        } else {
          if (!formData.name) {
            throw new Error("Display Name is required");
          }
          const user = signUp(formData.username, formData.password, formData.name);
          onLogin(user);
        }
      } catch (err: any) {
        setError(err.message || 'An error occurred');
        setIsLoading(false);
      }
    }, 500);
  };

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-900/20 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-emerald-900/20 rounded-full blur-[100px]"></div>
      </div>

      <div className="w-full max-w-md z-10">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-4 bg-gray-900 border border-gray-800 rounded-2xl mb-6 shadow-xl shadow-indigo-900/20">
            <Activity size={48} className="text-indigo-400" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">TradeJournal AI</h1>
          <p className="text-gray-400">Master your trading psychology.</p>
        </div>

        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 shadow-2xl backdrop-blur-sm bg-opacity-90">
          {/* Tabs */}
          <div className="flex mb-6 bg-gray-950 rounded-lg p-1 border border-gray-800">
            <button
              onClick={() => { setIsLogin(true); setError(null); }}
              className={`flex-1 py-2 text-sm font-medium rounded-md transition-all flex items-center justify-center gap-2 ${isLogin ? 'bg-gray-800 text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
            >
              <LogIn size={16} /> Sign In
            </button>
            <button
              onClick={() => { setIsLogin(false); setError(null); }}
              className={`flex-1 py-2 text-sm font-medium rounded-md transition-all flex items-center justify-center gap-2 ${!isLogin ? 'bg-gray-800 text-white shadow-sm' : 'text-gray-400 hover:text-white'}`}
            >
              <UserPlus size={16} /> Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1 ml-1">Display Name</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="e.g. Top Trader"
                  className="w-full bg-gray-950 border border-gray-700 rounded-xl p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1 ml-1">Username</label>
              <input 
                type="text" 
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                placeholder="Enter username"
                required
                className="w-full bg-gray-950 border border-gray-700 rounded-xl p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1 ml-1">Password</label>
              <input 
                type="password" 
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                placeholder="Enter password"
                required
                className="w-full bg-gray-950 border border-gray-700 rounded-xl p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
              />
            </div>

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm text-center animate-pulse">
                {error}
              </div>
            )}

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold py-4 rounded-xl transition-all transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-indigo-900/20 mt-4"
            >
              {isLoading ? (
                 <span>Processing...</span>
              ) : (
                 <>
                  <span>{isLogin ? 'Access Journal' : 'Create Account'}</span>
                  <ArrowRight size={20} />
                 </>
              )}
            </button>
          </form>
        </div>

        <div className="mt-8 text-center">
          <p className="text-xs text-gray-500 flex items-center justify-center gap-1">
            <ShieldCheck size={12} />
            Secure local encryption.
          </p>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { X, Download, Upload, Save, User, AlertTriangle, LogOut } from 'lucide-react';
import { UserSettings } from '../types';
import { exportData, importData, updateUserProfile } from '../services/storageService';

interface UserProfileModalProps {
  currentUser: UserSettings;
  onClose: () => void;
  onDataImported: () => void;
  onLogout: () => void;
  onUpdateProfile: (user: UserSettings) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ currentUser, onClose, onDataImported, onLogout, onUpdateProfile }) => {
  const [name, setName] = useState(currentUser.name);
  const [saved, setSaved] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setName(currentUser.name);
  }, [currentUser]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedUser = updateUserProfile(currentUser.username, name);
    onUpdateProfile(updatedUser);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleExport = () => {
    const data = exportData(currentUser.username);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tradejournal_${currentUser.username}_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      const success = importData(result, currentUser.username);
      if (success) {
        onDataImported();
        onClose();
        alert('Data restored successfully!');
      } else {
        setImportError('Invalid backup file. Please check the format.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-gray-900 w-full max-w-md rounded-2xl border border-gray-800 shadow-2xl p-6">
        <div className="flex justify-between items-center mb-6 border-b border-gray-800 pb-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <User className="text-indigo-400" />
            @{currentUser.username}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        <div className="space-y-6">
            <form onSubmit={handleSave}>
            <label className="block text-sm font-medium text-gray-400 mb-2">Display Name</label>
            <div className="flex gap-2">
                <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                className="flex-1 bg-gray-950 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <button 
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 rounded-lg font-medium transition-colors flex items-center gap-2"
                >
                <Save size={18} />
                {saved ? 'Saved' : 'Save'}
                </button>
            </div>
            </form>

            <div className="bg-gray-800/50 rounded-xl p-4 border border-gray-700">
            <h3 className="text-white font-bold mb-2 flex items-center gap-2">
                <AlertTriangle size={16} className="text-yellow-500" />
                Data Management
            </h3>
            <p className="text-sm text-gray-400 mb-4">
                Export your data to backup or transfer to another device. Importing will overwrite current entries for <strong>@{currentUser.username}</strong>.
            </p>
            
            <div className="grid grid-cols-2 gap-4">
                <button 
                onClick={handleExport}
                className="flex flex-col items-center justify-center gap-2 bg-gray-900 hover:bg-gray-800 border border-gray-700 text-gray-200 p-4 rounded-xl transition-colors"
                >
                <Download size={24} className="text-emerald-400" />
                <span className="font-semibold text-sm">Export Data</span>
                </button>

                <button 
                onClick={handleImportClick}
                className="flex flex-col items-center justify-center gap-2 bg-gray-900 hover:bg-gray-800 border border-gray-700 text-gray-200 p-4 rounded-xl transition-colors"
                >
                <Upload size={24} className="text-blue-400" />
                <span className="font-semibold text-sm">Import Data</span>
                </button>
                <input 
                type="file" 
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".json"
                className="hidden"
                />
            </div>
            
            {importError && (
                <p className="text-red-400 text-xs mt-3 text-center">{importError}</p>
            )}
            </div>

            <div className="border-t border-gray-800 pt-4">
                <button 
                    onClick={onLogout}
                    className="w-full flex items-center justify-center gap-2 text-red-400 hover:text-red-300 hover:bg-red-900/20 p-3 rounded-xl transition-colors"
                >
                    <LogOut size={18} />
                    Log Out
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

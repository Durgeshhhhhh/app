import React from 'react';
import { LayoutDashboard, BookOpen, PlusCircle, Activity, User } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: 'dashboard' | 'journal';
  setActiveTab: (tab: 'dashboard' | 'journal') => void;
  onAddTrade: () => void;
  onOpenProfile: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab, onAddTrade, onOpenProfile }) => {
  return (
    <div className="flex h-screen bg-gray-950 text-gray-100">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-900 border-r border-gray-800 hidden md:flex flex-col">
        <div className="p-6 border-b border-gray-800">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-emerald-400 bg-clip-text text-transparent flex items-center gap-2">
            <Activity className="text-indigo-400" />
            TradeJournal
          </h1>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              activeTab === 'dashboard' 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' 
                : 'text-gray-400 hover:bg-gray-800 hover:text-white'
            }`}
          >
            <LayoutDashboard size={20} />
            <span className="font-medium">Dashboard</span>
          </button>
          
          <button 
            onClick={() => setActiveTab('journal')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              activeTab === 'journal' 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' 
                : 'text-gray-400 hover:bg-gray-800 hover:text-white'
            }`}
          >
            <BookOpen size={20} />
            <span className="font-medium">Journal</span>
          </button>
        </nav>

        <div className="p-4 space-y-3 border-t border-gray-800">
          <button 
            onClick={onAddTrade}
            className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-3 rounded-xl font-bold transition-all transform hover:scale-105 shadow-lg shadow-emerald-900/20"
          >
            <PlusCircle size={20} />
            New Entry
          </button>
          
          <button 
            onClick={onOpenProfile}
            className="w-full flex items-center justify-center gap-2 text-gray-400 hover:text-white hover:bg-gray-800 px-4 py-2 rounded-xl transition-colors"
          >
            <User size={18} />
            User & Sync
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-gray-900 border-b border-gray-800 flex items-center justify-between px-4 z-40">
        <span className="font-bold text-lg text-white">TradeJournal</span>
        <button onClick={onAddTrade} className="p-2 bg-emerald-600 rounded-lg text-white">
            <PlusCircle size={20} />
        </button>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8 pt-20 md:pt-8 scrollbar-thin scrollbar-thumb-gray-800 scrollbar-track-transparent">
        {children}
      </main>

      {/* Mobile Bottom Nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-gray-900 border-t border-gray-800 flex justify-around items-center z-40">
        <button 
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center ${activeTab === 'dashboard' ? 'text-indigo-400' : 'text-gray-500'}`}
        >
            <LayoutDashboard size={24} />
            <span className="text-xs mt-1">Dash</span>
        </button>
        <button 
            onClick={() => setActiveTab('journal')}
            className={`flex flex-col items-center ${activeTab === 'journal' ? 'text-indigo-400' : 'text-gray-500'}`}
        >
            <BookOpen size={24} />
            <span className="text-xs mt-1">Journal</span>
        </button>
        <button 
            onClick={onOpenProfile}
            className="flex flex-col items-center text-gray-500"
        >
            <User size={24} />
            <span className="text-xs mt-1">Profile</span>
        </button>
      </div>
    </div>
  );
};
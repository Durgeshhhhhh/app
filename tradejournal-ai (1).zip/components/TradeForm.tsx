import React, { useState, useRef, useEffect } from 'react';
import { Camera, Upload, X, Trash2 } from 'lucide-react';
import { TradeEntry, TradeOutcome, TradeType } from '../types';
import { getWeekNumber } from '../services/storageService';
import { v4 as uuidv4 } from 'uuid';

interface TradeFormProps {
  onSave: (trade: TradeEntry) => void;
  onCancel: () => void;
  onDelete?: (id: string) => void;
  initialData?: TradeEntry | null;
}

export const TradeForm: React.FC<TradeFormProps> = ({ onSave, onCancel, onDelete, initialData }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<TradeEntry>>({
    type: TradeType.BUY,
    outcome: TradeOutcome.OPEN,
    date: new Date().toISOString().split('T')[0],
    ticker: '',
    price: 0,
    reason: '',
    aiAnalysis: '',
  });

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
      setPreview(initialData.imageUrl || null);
    }
  }, [initialData]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Preview only - No AI analysis as requested
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      setPreview(base64String);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.ticker || !formData.price) return;

    const dateObj = new Date(formData.date!);
    const newTrade: TradeEntry = {
      id: initialData?.id || uuidv4(),
      date: formData.date!,
      ticker: formData.ticker.toUpperCase(),
      price: Number(formData.price),
      type: formData.type!,
      outcome: formData.outcome!,
      reason: formData.reason || '',
      aiAnalysis: formData.aiAnalysis,
      imageUrl: preview || undefined,
      weekNumber: getWeekNumber(dateObj),
      year: dateObj.getFullYear(),
    };

    onSave(newTrade);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-gray-900 w-full max-w-2xl rounded-2xl border border-gray-800 shadow-2xl flex flex-col max-h-[90vh]">
        <div className="flex justify-between items-center p-6 border-b border-gray-800">
          <h2 className="text-2xl font-bold text-white">
            {initialData ? 'Edit Trade' : 'Log New Trade'}
          </h2>
          <button onClick={onCancel} className="text-gray-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        <div className="p-6 overflow-y-auto">
          <form id="trade-form" onSubmit={handleSubmit} className="space-y-6">
            
            {/* Image Upload Area */}
            <div 
              className={`relative border-2 border-dashed rounded-xl p-8 transition-colors flex flex-col items-center justify-center text-center cursor-pointer group ${
                preview ? 'border-emerald-500/50 bg-emerald-500/5' : 'border-gray-700 hover:border-indigo-500 hover:bg-gray-800'
              }`}
              onClick={() => fileInputRef.current?.click()}
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                accept="image/*" 
                className="hidden" 
              />
              
              {preview ? (
                <div className="relative w-full">
                    <img src={preview} alt="Preview" className="max-h-64 mx-auto rounded-lg shadow-md" />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-lg transition-opacity">
                        <p className="text-white font-medium flex items-center"><Camera className="mr-2"/> Change Image</p>
                    </div>
                </div>
              ) : (
                <>
                  <div className="bg-gray-800 p-4 rounded-full mb-4 group-hover:bg-indigo-500/20 transition-colors">
                    <Upload className="text-gray-400 group-hover:text-indigo-400" size={32} />
                  </div>
                  <h3 className="text-lg font-medium text-white">Upload Trade Screenshot</h3>
                  <p className="text-gray-500 mt-1">Click to browse or paste image.</p>
                </>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Ticker Symbol</label>
                <input 
                  type="text" 
                  required
                  value={formData.ticker}
                  onChange={(e) => setFormData({...formData, ticker: e.target.value})}
                  placeholder="e.g. BTC, AAPL"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none font-mono"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Entry Price</label>
                <input 
                  type="number" 
                  step="any"
                  required
                  value={formData.price}
                  onChange={(e) => setFormData({...formData, price: parseFloat(e.target.value)})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Trade Type</label>
                <div className="flex gap-2">
                  <button 
                    type="button"
                    onClick={() => setFormData({...formData, type: TradeType.BUY})}
                    className={`flex-1 py-3 rounded-lg font-semibold transition-colors ${formData.type === TradeType.BUY ? 'bg-emerald-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}
                  >
                    BUY / LONG
                  </button>
                  <button 
                    type="button"
                    onClick={() => setFormData({...formData, type: TradeType.SELL})}
                    className={`flex-1 py-3 rounded-lg font-semibold transition-colors ${formData.type === TradeType.SELL ? 'bg-red-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}
                  >
                    SELL / SHORT
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Outcome</label>
                <select 
                  value={formData.outcome}
                  onChange={(e) => setFormData({...formData, outcome: e.target.value as TradeOutcome})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                >
                  <option value={TradeOutcome.OPEN}>Open</option>
                  <option value={TradeOutcome.WIN}>Win</option>
                  <option value={TradeOutcome.LOSS}>Loss</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Date</label>
                <input 
                  type="date" 
                  required
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Analysis / Reason</label>
              <textarea 
                rows={4}
                value={formData.reason}
                onChange={(e) => setFormData({...formData, reason: e.target.value})}
                placeholder="Why did you take this trade? What was the setup?"
                className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              ></textarea>
            </div>

            {formData.aiAnalysis && (
               <div className="bg-indigo-900/20 border border-indigo-500/30 p-4 rounded-lg">
                 <p className="text-xs font-bold text-indigo-400 mb-1">AI SUGGESTION (Legacy)</p>
                 <p className="text-sm text-indigo-200 italic">{formData.aiAnalysis}</p>
               </div>
            )}

          </form>
        </div>

        <div className="p-6 border-t border-gray-800 flex justify-between items-center gap-4">
          {initialData && onDelete ? (
             <button 
               type="button"
               onClick={(e) => {
                  e.stopPropagation();
                  if (initialData) onDelete(initialData.id);
               }}
               className="flex items-center gap-2 px-4 py-2 rounded-lg text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-colors"
             >
               <Trash2 size={18} />
               <span>Delete</span>
             </button>
          ) : (
             <div className="w-0"></div>
          )}
          
          <div className="flex gap-4">
            <button 
                type="button" 
                onClick={onCancel}
                className="px-6 py-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
                Cancel
            </button>
            <button 
                type="submit" 
                form="trade-form"
                className="px-6 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow-lg shadow-indigo-500/20 transition-all transform hover:scale-105"
            >
                Save Entry
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
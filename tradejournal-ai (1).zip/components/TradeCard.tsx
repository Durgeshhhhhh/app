import React from 'react';
import { TradeEntry, TradeOutcome, TradeType } from '../types';
import { Trash2, Pencil } from 'lucide-react';

interface TradeCardProps {
  trade: TradeEntry;
  onDelete: (id: string) => void;
  onEdit: (trade: TradeEntry) => void;
}

export const TradeCard: React.FC<TradeCardProps> = ({ trade, onDelete, onEdit }) => {
  const isWin = trade.outcome === TradeOutcome.WIN;
  const isLoss = trade.outcome === TradeOutcome.LOSS;
  
  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden shadow-lg hover:border-gray-700 transition-colors group">
      <div className="relative h-48 bg-gray-800 overflow-hidden">
        {trade.imageUrl ? (
          <img 
            src={trade.imageUrl} 
            alt={`${trade.ticker} chart`} 
            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
          />
        ) : (
          <div className="flex items-center justify-center h-full text-gray-600">
            No Screenshot
          </div>
        )}
        <div className="absolute top-2 right-2 flex gap-2 z-10">
            <span className={`px-2 py-1 text-xs font-bold rounded ${
                trade.type === TradeType.BUY ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
            }`}>
                {trade.type}
            </span>
            <span className={`px-2 py-1 text-xs font-bold rounded ${
                isWin ? 'bg-green-500 text-white' : isLoss ? 'bg-red-600 text-white' : 'bg-indigo-500 text-white'
            }`}>
                {trade.outcome}
            </span>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="text-xl font-bold text-white">{trade.ticker}</h3>
            <p className="text-sm text-gray-400">{new Date(trade.date).toLocaleDateString()}</p>
          </div>
          <div className="text-right">
            <p className="text-white font-mono">${trade.price.toLocaleString()}</p>
          </div>
        </div>
        
        <div className="mt-3">
            <p className="text-sm text-gray-300 line-clamp-2" title={trade.reason}>
                <span className="text-gray-500 font-semibold">Reason:</span> {trade.reason}
            </p>
        </div>

        {trade.aiAnalysis && (
            <div className="mt-3 p-2 bg-indigo-950/30 border border-indigo-500/20 rounded text-xs text-indigo-200">
                <span className="font-bold text-indigo-400">AI Insight:</span> {trade.aiAnalysis}
            </div>
        )}

        {/* Action Buttons - Increased z-index to ensure clickability */}
        <div className="mt-4 flex justify-end gap-2 relative z-20">
          <button 
            type="button"
            onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onEdit(trade);
            }}
            className="cursor-pointer text-gray-500 hover:text-indigo-400 transition-colors p-2 rounded hover:bg-indigo-500/10"
            title="Edit Trade"
          >
            <Pencil size={18} />
          </button>
          <button 
            type="button"
            onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onDelete(trade.id);
            }}
            className="cursor-pointer text-gray-500 hover:text-red-400 transition-colors p-2 rounded hover:bg-red-500/10"
            title="Delete Trade"
          >
            <Trash2 size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};
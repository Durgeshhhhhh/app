import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { TradeEntry, TradeOutcome } from '../types';

interface StatsChartProps {
  trades: TradeEntry[];
}

const COLORS = {
  [TradeOutcome.WIN]: '#10b981', // emerald-500
  [TradeOutcome.LOSS]: '#ef4444', // red-500
  [TradeOutcome.OPEN]: '#6366f1', // indigo-500
};

export const StatsChart: React.FC<StatsChartProps> = ({ trades }) => {
  const data = [
    { name: 'Wins', value: trades.filter(t => t.outcome === TradeOutcome.WIN).length },
    { name: 'Losses', value: trades.filter(t => t.outcome === TradeOutcome.LOSS).length },
    { name: 'Open', value: trades.filter(t => t.outcome === TradeOutcome.OPEN).length },
  ].filter(d => d.value > 0);

  if (data.length === 0) {
    return <div className="text-gray-500 text-center py-8">No data to display</div>;
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[entry.name === 'Wins' ? TradeOutcome.WIN : entry.name === 'Losses' ? TradeOutcome.LOSS : TradeOutcome.OPEN]} />
            ))}
          </Pie>
          <Tooltip 
            contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px', color: '#fff' }}
          />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

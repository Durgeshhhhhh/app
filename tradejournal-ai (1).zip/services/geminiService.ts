import { GoogleGenAI, Type } from "@google/genai";
import { GeminiAnalysisResult, TradeType } from "../types";

const apiKey = process.env.API_KEY || ''; // Ensure API key is available
const ai = new GoogleGenAI({ apiKey });

export const analyzeTradeScreenshot = async (base64Image: string): Promise<GeminiAnalysisResult | null> => {
  try {
    // Remove data URL prefix if present for the API call logic if needed, 
    // but the library usually expects the base64 data directly or handles it.
    // The @google/genai library expects the raw base64 string in inlineData.
    const base64Data = base64Image.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg", // Assuming JPEG/PNG convert to generic or detect. Keeping simple for demo.
              data: base64Data
            }
          },
          {
            text: "Analyze this trading chart screenshot. Extract the Ticker Symbol, the likely Entry Price, and whether it looks like a Long (BUY) or Short (SELL) setup. Also describe the technical setup (e.g., breakout, support bounce) in one sentence."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            ticker: { type: Type.STRING, description: "The stock or crypto ticker symbol (e.g., BTC, AAPL)" },
            price: { type: Type.NUMBER, description: "The entry price visible or current price" },
            type: { type: Type.STRING, enum: ["BUY", "SELL"], description: "The trade direction" },
            reason_or_setup: { type: Type.STRING, description: "Brief technical analysis of the chart pattern" }
          },
          required: ["ticker", "type", "reason_or_setup"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as GeminiAnalysisResult;
    }
    return null;
  } catch (error) {
    console.error("Error analyzing image with Gemini:", error);
    throw error;
  }
};

export const generateWeeklySummary = async (trades: string, userName: string = 'Trader'): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Here is a list of my trades for the week in JSON format: ${trades}. 
      Please provide a concise 3-bullet point summary of my performance, highlighting common mistakes or good behaviors based on the 'reason' and 'outcome' fields. Address me as '${userName}'.`,
    });
    return response.text || "Could not generate summary.";
  } catch (error) {
    console.error("Error generating summary:", error);
    return "Unable to generate weekly summary at this time.";
  }
};
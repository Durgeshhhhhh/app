import { TradeEntry, UserSettings, UserAccount } from "../types";

const USERS_KEY = 'tradejournal_users'; // Stores { username: UserAccount }
const DATA_PREFIX = 'tradejournal_entries_';

// --- Auth Helpers ---

const getUsers = (): Record<string, UserAccount> => {
  const data = localStorage.getItem(USERS_KEY);
  return data ? JSON.parse(data) : {};
};

const saveUsers = (users: Record<string, UserAccount>) => {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const signUp = (username: string, password: string, name: string): UserSettings => {
  const users = getUsers();
  if (users[username]) {
    throw new Error('Username already exists');
  }
  
  const newUser: UserAccount = { username, password, name };
  users[username] = newUser;
  saveUsers(users);
  
  return { username, name };
};

export const signIn = (username: string, password: string): UserSettings => {
  const users = getUsers();
  const user = users[username];
  
  if (!user || user.password !== password) {
    throw new Error('Invalid username or password');
  }
  
  return { username: user.username, name: user.name };
};

export const updateUserProfile = (username: string, newName: string): UserSettings => {
  const users = getUsers();
  if (users[username]) {
    users[username].name = newName;
    saveUsers(users);
    return { username, name: newName };
  }
  return { username, name: newName };
};

// --- Data Helpers ---

const getUserKey = (username: string) => `${DATA_PREFIX}${username}`;

export const getTrades = (username: string): TradeEntry[] => {
  const data = localStorage.getItem(getUserKey(username));
  return data ? JSON.parse(data) : [];
};

export const saveTrade = (trade: TradeEntry, username: string): TradeEntry[] => {
  const trades = getTrades(username);
  const existingIndex = trades.findIndex((t) => t.id === trade.id);
  
  let newTrades;
  if (existingIndex >= 0) {
    newTrades = [...trades];
    newTrades[existingIndex] = trade;
  } else {
    newTrades = [trade, ...trades];
  }
  
  localStorage.setItem(getUserKey(username), JSON.stringify(newTrades));
  return newTrades;
};

export const deleteTrade = (id: string, username: string): TradeEntry[] => {
  const trades = getTrades(username);
  const newTrades = trades.filter((t) => String(t.id) !== String(id));
  localStorage.setItem(getUserKey(username), JSON.stringify(newTrades));
  return newTrades;
};

export const getWeekNumber = (d: Date): number => {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  return Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
};

// --- Import / Export ---

export const exportData = (username: string): string => {
  return localStorage.getItem(getUserKey(username)) || '[]';
};

export const importData = (jsonString: string, username: string): boolean => {
  try {
    const data = JSON.parse(jsonString);
    if (Array.isArray(data)) {
      localStorage.setItem(getUserKey(username), JSON.stringify(data));
      return true;
    }
    return false;
  } catch (e) {
    return false;
  }
};

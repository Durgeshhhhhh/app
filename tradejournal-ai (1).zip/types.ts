export enum TradeType {
  BUY = 'BUY',
  SELL = 'SELL',
}

export enum TradeOutcome {
  WIN = 'WIN',
  LOSS = 'LOSS',
  OPEN = 'OPEN',
}

export interface TradeEntry {
  id: string;
  date: string; // ISO string
  ticker: string;
  price: number;
  type: TradeType;
  outcome: TradeOutcome;
  reason: string;
  aiAnalysis?: string;
  imageUrl?: string; // Base64 data URI
  weekNumber: number;
  year: number;
}

export interface GeminiAnalysisResult {
  ticker: string;
  price: number;
  type: TradeType;
  reason_or_setup: string;
}

export interface UserSettings {
  username: string;
  name: string;
}

export interface UserAccount extends UserSettings {
  password: string; // Stored locally for simulation
}

import React, { useEffect, useState, useMemo } from 'react';
import { Layout } from './components/Layout';
import { TradeForm } from './components/TradeForm';
import { TradeCard } from './components/TradeCard';
import { StatsChart } from './components/StatsChart';
import { UserProfileModal } from './components/UserProfileModal';
import { LoginScreen } from './components/LoginScreen';
import { TradeEntry, UserSettings, TradeOutcome, TradeType } from './types';
import { getTrades, saveTrade, deleteTrade, getWeekNumber } from './services/storageService';
import { generateWeeklySummary } from './services/geminiService';
import { Filter, Calendar, Sparkles, Search, CheckCircle } from 'lucide-react';

const App: React.FC = () => {
  const [trades, setTrades] = useState<TradeEntry[]>([]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'journal'>('dashboard');
  const [showForm, setShowForm] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [editingTrade, setEditingTrade] = useState<TradeEntry | null>(null);
  const [selectedWeek, setSelectedWeek] = useState<number>(getWeekNumber(new Date()));
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [user, setUser] = useState<UserSettings | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterOutcome, setFilterOutcome] = useState<TradeOutcome | 'ALL'>('ALL');
  const [filterType, setFilterType] = useState<TradeType | 'ALL'>('ALL');
  const [toast, setToast] = useState<{ show: boolean; message: string }>({ show: false, message: '' });

  // Attempt to restore session from localStorage if we decided to persist session tokens,
  // but for this strictly client-side demo, we will require login on refresh or component mount 
  // to demonstrate the auth flow clearly. 
  // If you want persistence, we could check a 'session_user' key here.

  useEffect(() => {
    if (user) {
      loadData(user.username);
    }
  }, [user]);

  const loadData = (username: string) => {
    setTrades(getTrades(username));
  };

  const handleLogin = (loggedInUser: UserSettings) => {
    setUser(loggedInUser);
  };

  const handleLogout = () => {
    setUser(null);
    setShowProfile(false);
    setTrades([]);
    setAiSummary(null);
    setSearchQuery('');
    setFilterOutcome('ALL');
    setFilterType('ALL');
  };

  const handleAddTradeClick = () => {
    setEditingTrade(null);
    setShowForm(true);
  };

  const handleEditTradeClick = (trade: TradeEntry) => {
    setEditingTrade(trade);
    setShowForm(true);
  };

  const showSuccessToast = (message: string) => {
    setToast({ show: true, message });
    setTimeout(() => setToast(prev => ({ ...prev, show: false })), 3000);
  };

  const handleSaveTrade = (trade: TradeEntry) => {
    if (!user) return;
    const isEdit = !!editingTrade;
    const updatedTrades = saveTrade(trade, user.username);
    setTrades([...updatedTrades]); // Ensure new array reference
    setShowForm(false);
    setEditingTrade(null);
    showSuccessToast(isEdit ? 'Trade updated successfully' : 'Trade saved successfully');
  };

  const handleDeleteTrade = (id: string) => {
    if (!user) return false;
    
    // Explicit confirmation dialog
    if (window.confirm('Are you sure you want to delete this trade entry? This action cannot be undone.')) {
      try {
        const updatedTrades = deleteTrade(id, user.username);
        // Spread into a new array to ensure React detects the state change
        setTrades([...updatedTrades]);
        showSuccessToast('Trade deleted successfully');
        return true;
      } catch (error) {
        console.error("Failed to delete trade:", error);
        return false;
      }
    }
    return false;
  };

  // Group trades by week for filter dropdown
  const weeks = useMemo(() => {
    const uniqueWeeks = Array.from(new Set(trades.map(t => t.weekNumber))).sort((a: number, b: number) => b - a);
    return uniqueWeeks.length > 0 ? uniqueWeeks : [getWeekNumber(new Date())];
  }, [trades]);

  const filteredTrades = useMemo(() => {
    return trades.filter(t => {
      // Filter by Week
      if (t.weekNumber !== selectedWeek) return false;
      
      // Filter by Outcome
      if (filterOutcome !== 'ALL' && t.outcome !== filterOutcome) return false;

      // Filter by Type
      if (filterType !== 'ALL' && t.type !== filterType) return false;

      // Filter by Search Query
      if (searchQuery.trim() === '') return true;
      
      const query = searchQuery.toLowerCase();
      return (
        t.ticker.toLowerCase().includes(query) ||
        t.reason.toLowerCase().includes(query) ||
        t.outcome.toLowerCase().includes(query)
      );
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [trades, selectedWeek, searchQuery, filterOutcome, filterType]);

  const generateSummary = async () => {
    setLoadingSummary(true);
    try {
      // Minimize payload for AI
      const tradeData = filteredTrades.map(({ ticker, type, outcome, reason }) => ({ ticker, type, outcome, reason }));
      const summary = await generateWeeklySummary(JSON.stringify(tradeData), user?.name || 'Trader');
      setAiSummary(summary);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingSummary(false);
    }
  };

  // If not logged in, show Login Screen
  if (!user) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <Layout 
      activeTab={activeTab} 
      setActiveTab={setActiveTab} 
      onAddTrade={handleAddTradeClick}
      onOpenProfile={() => setShowProfile(true)}
    >
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-bold text-white">
            {activeTab === 'dashboard' ? 'Weekly Overview' : 'Trade Journal'}
          </h2>
          <p className="text-gray-400 mt-1">
            Welcome back, <span className="text-indigo-400 font-medium">{user.name}</span> • Week {selectedWeek}
          </p>
        </div>

        <div className="flex flex-col xl:flex-row items-start xl:items-center gap-4">
            {/* Search Bar */}
            <div className="w-full sm:w-auto flex items-center bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 focus-within:ring-2 focus-within:ring-indigo-500 focus-within:border-transparent transition-all shadow-sm">
                <Search size={18} className="text-gray-400 mr-2 flex-shrink-0" />
                <input
                    type="text"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-transparent border-none outline-none text-white text-sm w-full sm:w-48 placeholder-gray-500"
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="text-gray-500 hover:text-white ml-2">
                    <span className="sr-only">Clear</span>
                    ×
                  </button>
                )}
            </div>

            <div className="flex flex-wrap gap-3 w-full sm:w-auto">
                {/* Type Filter */}
                <div className="flex-1 sm:flex-none flex items-center gap-2 bg-gray-900 border border-gray-700 px-3 py-2 rounded-lg shadow-sm">
                    <span className="text-sm text-gray-400 whitespace-nowrap">Type:</span>
                    <select 
                        value={filterType} 
                        onChange={(e) => setFilterType(e.target.value as TradeType | 'ALL')}
                        className="bg-transparent text-white font-bold outline-none cursor-pointer w-full sm:w-auto"
                    >
                        <option value="ALL" className="bg-gray-900">All</option>
                        <option value={TradeType.BUY} className="bg-gray-900">Buy</option>
                        <option value={TradeType.SELL} className="bg-gray-900">Sell</option>
                    </select>
                </div>

                {/* Outcome Filter */}
                <div className="flex-1 sm:flex-none flex items-center gap-2 bg-gray-900 border border-gray-700 px-3 py-2 rounded-lg shadow-sm">
                    <span className="text-sm text-gray-400 whitespace-nowrap">Outcome:</span>
                    <select 
                        value={filterOutcome} 
                        onChange={(e) => setFilterOutcome(e.target.value as TradeOutcome | 'ALL')}
                        className="bg-transparent text-white font-bold outline-none cursor-pointer w-full sm:w-auto"
                    >
                        <option value="ALL" className="bg-gray-900">All</option>
                        <option value={TradeOutcome.WIN} className="bg-gray-900">Win</option>
                        <option value={TradeOutcome.LOSS} className="bg-gray-900">Loss</option>
                        <option value={TradeOutcome.OPEN} className="bg-gray-900">Open</option>
                    </select>
                </div>

                {/* Week Selector */}
                <div className="flex-1 sm:flex-none flex items-center gap-2 bg-gray-900 border border-gray-700 px-3 py-2 rounded-lg shadow-sm">
                    <Calendar size={16} className="text-gray-400 flex-shrink-0" />
                    <span className="text-sm text-gray-400 whitespace-nowrap">Week:</span>
                    <select 
                        value={selectedWeek} 
                        onChange={(e) => setSelectedWeek(Number(e.target.value))}
                        className="bg-transparent text-white font-bold outline-none cursor-pointer w-full sm:w-auto"
                    >
                        {weeks.map(w => (
                            <option key={w} value={w} className="bg-gray-900">Week {w}</option>
                        ))}
                    </select>
                </div>
            </div>
        </div>
      </div>

      {activeTab === 'dashboard' && (
        <div className="space-y-8">
          {/* Stats Row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Summary Card */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 col-span-1 lg:col-span-2 shadow-lg shadow-black/20">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Sparkles className="text-indigo-400" size={20} />
                  AI Weekly Insight
                </h3>
                <button 
                  onClick={generateSummary} 
                  disabled={loadingSummary || filteredTrades.length === 0}
                  className="text-sm bg-indigo-600/20 text-indigo-300 px-3 py-1 rounded hover:bg-indigo-600/30 disabled:opacity-50 transition-colors"
                >
                  {loadingSummary ? 'Generating...' : 'Generate Insight'}
                </button>
              </div>
              <div className="bg-gray-950/50 rounded-xl p-4 border border-gray-800 min-h-[120px]">
                {aiSummary ? (
                  <div className="prose prose-invert prose-sm">
                    <p className="whitespace-pre-line leading-relaxed">{aiSummary}</p>
                  </div>
                ) : filteredTrades.length === 0 ? (
                  <p className="text-gray-500 text-center mt-8">No trades match your filters.</p>
                ) : (
                  <p className="text-gray-500 text-center mt-8">Click 'Generate Insight' to analyze your weekly performance.</p>
                )}
              </div>
            </div>

            {/* Win Rate Chart */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 flex flex-col items-center justify-center shadow-lg shadow-black/20">
               <h3 className="text-lg font-bold text-gray-300 mb-2 self-start w-full">Outcome Distribution</h3>
               <StatsChart trades={filteredTrades} />
            </div>
          </div>

          {/* Recent Trades Preview */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">
                {(searchQuery || filterOutcome !== 'ALL' || filterType !== 'ALL') ? 'Filtered Results' : 'Recent Activity'}
            </h3>
            {filteredTrades.length > 0 ? (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 {filteredTrades.slice(0, 3).map(trade => (
                   <TradeCard 
                    key={trade.id} 
                    trade={trade} 
                    onDelete={handleDeleteTrade} 
                    onEdit={handleEditTradeClick}
                   />
                 ))}
               </div>
            ) : (
                <div className="text-gray-500 italic">
                    {(searchQuery || filterOutcome !== 'ALL' || filterType !== 'ALL') ? 'No trades match your filters.' : 'No recent activity. Log a trade to get started.'}
                </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'journal' && (
        <div className="space-y-6">
            {filteredTrades.length === 0 ? (
                 <div className="flex flex-col items-center justify-center py-20">
                    <div className="bg-gray-800 p-6 rounded-full mb-4">
                        {(searchQuery || filterOutcome !== 'ALL' || filterType !== 'ALL') ? <Filter className="text-gray-600" size={48} /> : <Filter className="text-gray-600" size={48} />}
                    </div>
                    <h3 className="text-xl text-white font-bold">
                        {(searchQuery || filterOutcome !== 'ALL' || filterType !== 'ALL') ? 'No matches found' : 'No trades found'}
                    </h3>
                    <p className="text-gray-500 mt-2">
                        {(searchQuery || filterOutcome !== 'ALL' || filterType !== 'ALL')
                            ? `No trades match your current filters for Week ${selectedWeek}.` 
                            : `There are no trades for Week ${selectedWeek}.`}
                    </p>
                    {!(searchQuery || filterOutcome !== 'ALL' || filterType !== 'ALL') && (
                        <button onClick={handleAddTradeClick} className="mt-6 text-emerald-400 hover:underline">
                            Log your first trade
                        </button>
                    )}
                 </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {filteredTrades.map(trade => (
                    <TradeCard 
                        key={trade.id} 
                        trade={trade} 
                        onDelete={handleDeleteTrade}
                        onEdit={handleEditTradeClick}
                    />
                    ))}
                </div>
            )}
        </div>
      )}

      {showForm && (
        <TradeForm 
          initialData={editingTrade}
          onSave={handleSaveTrade} 
          onCancel={() => { setShowForm(false); setEditingTrade(null); }} 
          onDelete={(id) => {
             if (handleDeleteTrade(id)) {
                setShowForm(false);
                setEditingTrade(null);
             }
          }}
        />
      )}

      {showProfile && user && (
        <UserProfileModal 
            currentUser={user}
            onClose={() => setShowProfile(false)}
            onDataImported={() => {
                loadData(user.username);
            }}
            onLogout={handleLogout}
            onUpdateProfile={(updatedUser) => setUser(updatedUser)}
        />
      )}

      {toast.show && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-6 py-3 rounded-xl shadow-xl shadow-emerald-900/20 flex items-center gap-3 transition-all transform translate-y-0 opacity-100 animate-bounce">
           <CheckCircle size={22} className="text-emerald-100" />
           <span className="font-medium">{toast.message}</span>
        </div>
      )}
    </Layout>
  );
};

export default App;